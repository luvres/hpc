# BC K8s Jupyter

Batch connect Jupyter application
