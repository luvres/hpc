```
tee code-server.def <<EoF
Bootstrap:docker
From: codercom/code-server:latest

%environment
  export PS1="\[\e]0;\u@\h: \w\a\]\${debian_chroot:+(\$debian_chroot)}\[\033[01;32m\]\u@\h\[\033[00m\]:\[\033[01;34m\]\w\[\033[00m\]\\$ "

%runscript
  code-server "\$@"
EoF
```

### build
```
apptainer build ./code-server.sif ./code-server.def
sudo mv ./code-server.sif /scratch/img-apps/
sudo ln -s /scratch/img-apps/code-server.sif /opt/img-apps/
```
